package com.training.olxAdvertise.entities;

public enum Active {
	OPEN, CLOSED;
}