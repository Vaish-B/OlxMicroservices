package com.example.product.entities;

public class ProductDetail {

}
