package com.training.olxmasterdata.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.training.olxmasterdata.entities.AdvStatus;
import com.training.olxmasterdata.repository.AdvStatusRepository;

@Service
public class AdvStatusServiceImpl implements AdvStatusService {
	
	@Autowired
	AdvStatusRepository repository;

	@Override
	public List<AdvStatus> allStatus() {
		return (List<AdvStatus>) repository.findAll();
	}

}