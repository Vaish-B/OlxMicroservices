package com.training.olxmasterdata.service;

import java.util.List;


import com.training.olxmasterdata.entities.Categories;

import java.util.List;

import com.training.olxmasterdata.entities.Categories;

public interface CategoriesService {
	
	public List<Categories> allCategories();

}