package com.training.olxmasterdata.service;

import java.util.List;

import com.training.olxmasterdata.entities.AdvStatus;

public interface AdvStatusService {
	
	public List<AdvStatus> allStatus();

}