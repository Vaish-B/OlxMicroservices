package com.training.olxmasterdata.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class CategoryServiceImplTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
